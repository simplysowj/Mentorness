info = {
   "Pronoun": "her", 
   "Name": "Sowjanya",
   "Full_Name": "Sowjanya Bojja",
   "Intro": "Data Scientist",
   "About":"Hey there, I'm Sowjanya! I'm passionate about leveraging data and technology to drive meaningful insights and solutions in business.",
   "Github":"https://github.com/simplysowj",
   "Linkedin":"https://www.linkedin.com/in/sowjanya-bojja/",
   "City":"India",
  "Photo": "https://www.linkedin.com/in/sowjanya-bojja/",

   "Email": "simplysowj@gmail.com"
}
embed_rss= {
    
}


